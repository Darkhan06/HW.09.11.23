public class Main {
    public static void main(String[] args) {
        /* 1 задание */
        char g = 'G';
        int i = 89;
        byte b = 4;
        short s = 56;
        float f = 4.7333436F;
        double d = 4.355453532;
        long l = 12121;
        System.out.println("char =" + g);
        System.out.println("int =" + i);
        System.out.println("byte=" + b);
        System.out.println("short=" + s);
        System.out.println("float=" + f);
        System.out.println("double=" + d);
        System.out.println("long=" + l);

        /* 2 задание */
        System.out.println("Число 345 -> 3,4,5");
        System.out.println("Число 987 -> 9,8,7");

        /* Доп практика */
        //1
        byte byt = 127;
        System.out.println(byt);
        byt++;
        System.out.println(byt);//byt++

        //2
        byte z = 5;
        float x = 5.5F;
        System.out.println(z*x);

        //3
        char a = 'A';
        System.out.println(a);a++;
        System.out.println(a);
    }
}